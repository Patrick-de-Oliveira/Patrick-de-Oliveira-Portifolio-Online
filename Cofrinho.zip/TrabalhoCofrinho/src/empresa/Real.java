package empresa;

class Real extends Moeda {
    public Real(double valor) {
        super(valor, "Real");
    }

    @Override
    public double converterParaReal() {
        return valor; // Moedas em Real j� est�o em Real
    }
}