package empresa;

public class Dolar extends Moeda {
    private double taxaDeConversaoDoDolar;

    public Dolar(double valor, double taxaDeConversao) {
        super(valor, "Dolar");
        this.taxaDeConversaoDoDolar = taxaDeConversao;
    }

    @Override
    public double converterParaReal() {
        // L�gica de convers�o para Real
        return valor * taxaDeConversaoDoDolar;
    }
}