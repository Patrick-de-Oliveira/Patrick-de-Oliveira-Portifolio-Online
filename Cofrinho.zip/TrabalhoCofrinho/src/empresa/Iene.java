package empresa;

class Iene extends Moeda {
    private double taxaDeConversaoDoIene;

    public Iene(double valor) {
        super(valor, "Iene");
        // Inicialize a taxaDeConversaoDoIene conforme necess�rio
    }

    @Override
    public double converterParaReal() {
        // L�gica de convers�o para Real
        return valor * taxaDeConversaoDoIene;
    }
}
