package empresa;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cofrinho cofrinho = new Cofrinho();

        boolean sair = false;

        while (!sair) {
            System.out.println("O que deseja fazer:"); //menu para o usu�rio
            System.out.println("1- Inserir Moedas");
            System.out.println("2- Deletar Moedas");
            System.out.println("3- Ver a lista de moedas");
            System.out.println("4- Converter total para Reais");
            System.out.println("5- Encerrar");
            int escolha = scanner.nextInt();

            switch (escolha) {
                case 1:
                    System.out.println("Moeda desejada: "); // escolha da moeda
                    System.out.println("1- Dolar");
                    System.out.println("2- Euro");
                    System.out.println("3- Real");
                    System.out.println("4- Iene");
                    int tipoMoeda = scanner.nextInt();

                    System.out.println("Insira o valor:");
                    double valorMoeda = scanner.nextDouble();

                    Moeda novaMoeda;

                    switch (tipoMoeda) {
                        case 1:
                            novaMoeda = new Dolar(valorMoeda, valorMoeda);
                            break;
                        case 2:
                            novaMoeda = new Euro(valorMoeda);
                            break;
                        case 3:
                            novaMoeda = new Real(valorMoeda);
                            break;
                        case 4:
                            novaMoeda = new Iene(valorMoeda);
                            break;
                        default:
                            System.out.println("Op��o inv�lida.");
                            continue;
                    }

                    cofrinho.adicionarMoeda(novaMoeda);
                    break;

                case 2:
                    System.out.println("Insira o �ndice da moeda que deseja remover:");
                    int indice = scanner.nextInt();
                    Moeda moedaRemovida = cofrinho.removerMoeda(indice);
                    if (moedaRemovida != null) {
                        System.out.println("Moeda removida: " + moedaRemovida);
                    } else {
                        System.out.println("�ndice inv�lido.");
                    }
                    break;

                case 3:
                    System.out.println("Moedas no cofrinho:");
                    cofrinho.listarMoedas();
                    break;

                case 4:
                    double totalReal = cofrinho.calcularTotalEmReal();
                    System.out.println("Total em Real: " + totalReal);
                    break;

                case 5:
                    sair = true;
                    break;

                default:
                    System.out.println("Op��o inv�lida.");
                    break;
            }
        }

        System.out.println("Programa encerrado.");
    }
}