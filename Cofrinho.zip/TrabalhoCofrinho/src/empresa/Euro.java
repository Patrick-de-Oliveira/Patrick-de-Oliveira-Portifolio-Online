package empresa;

class Euro extends Moeda {
    private double taxaDeConversaoDoEuro;

    public Euro(double valor) {
        super(valor, "Euro");
        // Inicialize a taxaDeConversaoDoEuro conforme necess�rio
    }

    @Override
    public double converterParaReal() {
        // L�gica de convers�o para Real
        return valor * taxaDeConversaoDoEuro;
    }
}
