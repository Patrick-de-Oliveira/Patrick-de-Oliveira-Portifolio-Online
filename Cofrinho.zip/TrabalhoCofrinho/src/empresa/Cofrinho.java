package empresa;

import java.util.ArrayList;

class Cofrinho {
    private ArrayList<Moeda> moedas;

    public Cofrinho() {
        moedas = new ArrayList<>();
    }

    public void adicionarMoeda(Moeda moeda) {
        moedas.add(moeda);
    }

    public Moeda removerMoeda(int indice) {
        if (indice >= 0 && indice < moedas.size()) {
            return moedas.remove(indice);
        }
        return null;
    }

    public void listarMoedas() {
        for (int i = 0; i < moedas.size(); i++) {
            System.out.println("�ndice " + i + ": " + moedas.get(i));
        }
    }

    public double calcularTotalEmReal() {
        double total = 0;
        for (Moeda moeda : moedas) {
            total += moeda.converterParaReal();
        }
        return total;
    }
}